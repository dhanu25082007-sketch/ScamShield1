# Architecture Decisions

## Browser-first prototype
A lightweight HTML/CSS/JavaScript prototype was selected so the core flow can run immediately.

## Explainable scoring
The prototype shows a score and the indicators that contributed to it.

## Risk assessment
ScamShield provides a risk assessment rather than claiming certainty that content is fraudulent.

## Future
AI/NLP analysis and URL reputation services can be integrated after the basic prototype is tested.

# ScamShield 🛡️

AI-Powered Fake Message & Link Risk Detector.

## Features
- Suspicious message analysis
- Risk score
- Low / Suspicious / High classification
- Warning-sign explanation
- Safety recommendations

## Run
Open `index.html` in a browser.

ScamShield is a risk-assessment and awareness tool; it does not guarantee that content is genuine or fraudulent.

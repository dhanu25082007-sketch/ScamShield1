function analyze(){
const t=document.getElementById('message').value.trim().toLowerCase();
if(!t){alert('Please enter a message or URL.');return;}
let score=0,r=[];
if(['urgent','immediately','act now','limited time'].some(x=>t.includes(x))){score+=25;r.push('Urgent or pressure-based language detected.');}
if(['won','winner','prize','lottery','reward','congratulations'].some(x=>t.includes(x))){score+=25;r.push('Possible unrealistic reward or prize claim detected.');}
if(['otp','password','bank details','cvv','payment','upi'].some(x=>t.includes(x))){score+=30;r.push('Request for financial or sensitive information detected.');}
if(['http://','https://','bit.ly','tinyurl','click here'].some(x=>t.includes(x))){score+=20;r.push('Potentially suspicious link or click request detected.');}
score=Math.min(score,100);
let level=score>=70?'HIGH RISK':score>=35?'SUSPICIOUS':'LOW RISK';
if(!r.length)r.push('No common scam indicators were detected by the current prototype rules.');
document.getElementById('result').classList.remove('hidden');
document.getElementById('risk').textContent=level+' — '+score+'/100';
document.getElementById('reasons').innerHTML=r.map(x=>'<li>'+x+'</li>').join('');
document.getElementById('advice').textContent=score>=35?'Safety advice: Do not click unknown links or share OTPs, passwords or banking details. Verify suspicious requests through official channels.':'Safety advice: Continue to verify unexpected messages and avoid sharing sensitive information.';
}